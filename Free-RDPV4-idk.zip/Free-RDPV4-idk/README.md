

<h1 align="center">
- FREE-RDPV4 - <br></h1>
<p align="center">
<img src="https://telegra.ph/file/eb6385fa8df27fc50cc46.jpg?height="428" width="428"/>
</p>

------

# ```RDP Info```
<p align="center">
<a href="https://github.com/RavensVenix/"><img title="Open Source" src="https://img.shields.io/badge/Author-RavensVenix-red"></a>
<a href="https://github.com/RavensVenix/zxorkta/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-Idk%3F-yellow"></a>&nbsp;&nbsp;
</p>
<p align='center'>
<img src="https://telegra.ph/file/5bf4a4ba31018e89808ed.jpg?height="428" width="428"/>
    </p>

-------

<h3 align="center">Made by :</h3>
<p align="center">
  <a href="https://github.com/RavensVenix"><img src="https://github.com/RavensVenix.png?size=128" height="128" width="128" /></a>
    </p>

-------

#
### 📮 Terms & conditions
1. Don't sell this script!
2. Appreciate the Developer, don't admit that you are the developer!
3. If you have this script without obfuscated code then use it wisely, don't sell/claim to be a developer and don't share it arbitrarily!
4. Don't misuse this script!

-------
## ```Let's be friends !```
<p align="center">
<a href="https://wa.me/6281338302495?text=menu"><img src="https://img.shields.io/badge/-BOT%20NUMBER-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://wa.me/6281338302495"><img src="https://img.shields.io/badge/-CONTACT%20CECILIA-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://chat.whatsapp.com/EJ0c8rr1jrJK7BvxNOZFs2"><img src="https://img.shields.io/badge/Join Official GC-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://discordapp.com/users/989346417107689513"><img src="https://img.shields.io/badge/discord-195EFF?style=for-the-badge&logo=Discord&logoColor=ffffff&link=https://www.youtube.com/c/BOTINDO" />
<a href="t.me/vmxone"><img src="https://img.shields.io/badge/Telegram-195EFF?style=for-the-badge&logo=telegram&logoColor=ff000000&link=https://www.youtube.com/c/BOTINDO" /><br>
<a href=https://www.youtube.com/watch?v=9XcBDbFm8NA"><img src="https://img.shields.io/badge/-Video-FF0000?style=for-the-badge&logo=youtube&logoColor=white" />
</p>

## ```Donate Me```

- [`Saweria.co`](https://saweria.co/xylaa)
- [`Nyawer.co`](https://nyawer.co/cecilia)
- [`Sociabuzz.com`](https://sociabuzz.com/luciaximena/tribe)
- [`Trakteer.id`](https://trakteer.id/xylaa.ah/tip?quantity=1)

<p align="left">
Donate me if you want :)
</p>
